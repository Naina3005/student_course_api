Student Course Management API 

The Student Course Management API is a RESTful service built using FastAPI, SQLAlchemy, and Pydantic, designed to manage students, courses, and their enrollments. It supports the creation of students and courses, enrolling students in courses (many-to-many), and retrieving details of students or courses along with their associated enrollments. This project uses SQLite for testing and PostgreSQL for production, with optional support for Alembic (for schema migrations) and Pytest (for testing).   


Setup Instructions 


1.Clone the repository 

git clone <repo-url>
cd student_course_api 

2.Create and activate a virtual environment 

python -m venv venv
venv\Scripts\activate


3.Install the dependencies 

pip install -r requirements.txt
# or individually
pip install fastapi uvicorn sqlalchemy pydantic[email] alembic

4.Run the application 

uvicorn app.main:app --reload 

5.Access the API docs 

Open your browser and navigate to:
http://127.0.0.1:8000/docs
 

6.API Endpoints 

POST /students/ – Create a student

POST /courses/ – Create a course

POST /enroll/ – Enroll a student in a course

GET /students/{id} – Get student details with enrolled courses

GET /courses/{id} – Get course details with enrolled students 


Sample curl Commands 


1.Create a student 

curl -X POST http://127.0.0.1:8000/students/ \
-H "Content-Type: application/json" \
-d '{"name": "John", "email": "john@example.com"}'


2. Create a course 

curl -X POST http://127.0.0.1:8000/courses/ \
-H "Content-Type: application/json" \
-d '{"title": "Math", "description": "Basic Math Course"}'

3.Enroll a student in a course  

curl -X POST http://127.0.0.1:8000/enroll/ \
-H "Content-Type: application/json" \
-d '{"student_id": 1, "course_id": 1}'


4.Get student with enrollments 

curl http://127.0.0.1:8000/students/1


5.Get course with enrolled students  

curl http://127.0.0.1:8000/courses/1



