from pydantic import BaseModel, EmailStr
from typing import List, Optional
from datetime import datetime

class CourseBase(BaseModel):
    title: str
    description: str

class CourseCreate(CourseBase): pass

class CourseOut(CourseBase):
    id: int
    students: Optional[List['StudentOut']] = [] 


    class Config:
        from_attributes = True

   


class StudentBase(BaseModel):
    name: str
    email: EmailStr

class StudentCreate(StudentBase): pass

class StudentOut(StudentBase):
    id: int
    courses: Optional[List[CourseOut]] = []

    class Config:
        from_attributes = True

class EnrollRequest(BaseModel):
    student_id: int
    course_id: int

CourseOut.update_forward_refs()
StudentOut.update_forward_refs()
