from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from .. import schemas, crud, database

router = APIRouter(tags=["Enrollments"])

@router.post("/enroll/")
def enroll(enroll_req: schemas.EnrollRequest, db: Session = Depends(database.SessionLocal)):
    return crud.enroll_student(db, enroll_req.student_id, enroll_req.course_id)
