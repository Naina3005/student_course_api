from fastapi import FastAPI
from .database import Base, engine
from .routers import student, course, enrollment

app = FastAPI(title="Student Course Management API")

Base.metadata.create_all(bind=engine)

app.include_router(student.router)
app.include_router(course.router)
app.include_router(enrollment.router)
